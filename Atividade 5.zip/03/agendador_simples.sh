#!/bin/bash
# Simula um agendador (roda toda segunda às 3h)

while true; do
    # Pega o dia da semana (1 = segunda)
    DIA=$(date +%u)
    HORA=$(date +%H)
    MINUTO=$(date +%M)
    
    # Verifica se é segunda-feira às 3:00
    if [ $DIA -eq 1 ] && [ $HORA -eq 3 ] && [ $MINUTO -eq 0 ]; then
        echo "$(date): Executando job..." >> log_agendador.txt
        ./job_emails.sh
        # Espera 61 segundos para não executar múltiplas vezes
        sleep 61
    fi
    
    # Espera 30 segundos antes de verificar novamente
    sleep 30
done
