#!/bin/bash
# Script: job_emails.sh
# Executa a extração de emails e salva o resultado

# Configurações
SCRIPT_DIR="/c/Users/xande/Downloads/script1"
ARQUIVO_ORIGEM="$SCRIPT_DIR/contatos.txt"
DATA=$(date +%Y%m%d_%H%M%S)
RELATORIO_DIR="$SCRIPT_DIR/relatorios_emails"
RELATORIO="$RELATORIO_DIR/emails_$DATA.txt"

# Criar diretório de relatórios se não existir
mkdir -p "$RELATORIO_DIR"

# Função para extrair emails
extrai_emails() {
    grep -E -o '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' "$1" | sort -u
}

# Verificar se o arquivo de origem existe
if [ ! -f "$ARQUIVO_ORIGEM" ]; then
    echo "ERRO: Arquivo $ARQUIVO_ORIGEM não encontrado!" >> "$RELATORIO"
    exit 1
fi

# Gerar relatório
echo "=== RELATÓRIO DE EMAILS - $(date) ===" > "$RELATORIO"
echo "" >> "$RELATORIO"
echo "Arquivo fonte: $ARQUIVO_ORIGEM" >> "$RELATORIO"
echo "" >> "$RELATORIO"
echo "Emails encontrados:" >> "$RELATORIO"
echo "-------------------" >> "$RELATORIO"
extrai_emails "$ARQUIVO_ORIGEM" >> "$RELATORIO"
echo "" >> "$RELATORIO"
echo "Total de emails: $(extrai_emails "$ARQUIVO_ORIGEM" | wc -l)" >> "$RELATORIO"
echo "" >> "$RELATORIO"
echo "Relatório gerado automaticamente pelo crontab" >> "$RELATORIO"

# Log da execução
echo "$(date): Script executado - Relatório gerado: $RELATORIO" >> "$SCRIPT_DIR/log_crontab.txt"

echo "Relatório gerado: $RELATORIO"
