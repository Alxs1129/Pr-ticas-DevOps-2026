#!/bin/bash

extrai_emails() {
    grep -E -o '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' "$1"
}

# Testar
echo "Emails encontrados:"
extrai_emails "emails_exemplo.txt"
