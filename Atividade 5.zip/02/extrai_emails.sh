#!/bin/bash
# Script: extrai_emails.sh
# Função para extrair emails de um arquivo

# Função que recebe um arquivo e extrai emails
extrai_emails() {
    # Verifica se o arquivo existe
    if [ ! -f "$1" ]; then
        echo "Erro: Arquivo '$1' não encontrado!"
        return 1
    fi
    
    # Expressão regular para encontrar emails
    # Padrão: texto@texto.texto (domínio com pelo menos 2 letras)
    grep -E -o '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' "$1" | sort -u
}

# Verificar se recebeu um argumento
if [ $# -ne 1 ]; then
    echo "Uso: $0 <arquivo>"
    echo "Exemplo: $0 emails.txt"
    echo ""
    echo "Criando arquivo de exemplo para teste..."
    
    # Criar arquivo de exemplo
    cat > emails_exemplo.txt << 'EOF'
Contatos:
joao.silva@email.com
maria@empresa.com.br
contato@site.net
joao.silva@email.com (repetido)
email_invalido@
site.com
fulano@
ciclano@gmail.com
teste@dominio.org
anabeatriz@faculdade.edu.br
EOF
    
    echo "Arquivo 'emails_exemplo.txt' criado!"
    echo ""
    echo "Executando teste com o arquivo exemplo..."
    echo "========================================="
    extrai_emails "emails_exemplo.txt"
    exit 0
fi

# Executar a função com o arquivo informado
echo "Extraindo emails do arquivo: $1"
echo "========================================="
extrai_emails "$1"
