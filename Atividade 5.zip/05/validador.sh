#!/bin/bash
# Script: validador.sh
# Funções para validar email, CPF e data

# Cores para melhor visualização
VERDE="\033[32m"
VERMELHO="\033[31m"
AMARELO="\033[33m"
RESET="\033[0m"

# Função para validar email
valida_email() {
    local email=$1
    local regex="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    
    if [[ -z "$email" ]]; then
        echo -e "${VERMELHO}Inválido${RESET} - Email não pode estar vazio"
        return 1
    fi
    
    if [[ "$email" =~ $regex ]]; then
        echo -e "${VERDE}Válido${RESET} - $email é um email correto"
        return 0
    else
        echo -e "${VERMELHO}Inválido${RESET} - Formato de email incorreto"
        echo "Exemplo válido: nome@dominio.com"
        return 1
    fi
}

# Função para validar CPF
valida_cpf() {
    local cpf=$1
    # Remove caracteres não numéricos
    cpf=$(echo "$cpf" | tr -d '.-')
    
    # Verifica se tem 11 dígitos
    if [[ ${#cpf} -ne 11 ]]; then
        echo -e "${VERMELHO}Inválido${RESET} - CPF deve ter 11 dígitos"
        return 1
    fi
    
    # Verifica se todos os dígitos são iguais
    if [[ "$cpf" =~ ^([0-9])\1{10}$ ]]; then
        echo -e "${VERMELHO}Inválido${RESET} - CPF inválido (dígitos repetidos)"
        return 1
    fi
    
    # Cálculo do primeiro dígito verificador
    local soma=0
    for i in {0..8}; do
        soma=$((soma + ${cpf:$i:1} * (10 - i)))
    done
    local digito1=$((11 - (soma % 11)))
    [[ $digito1 -ge 10 ]] && digito1=0
    
    # Cálculo do segundo dígito verificador
    soma=0
    for i in {0..9}; do
        soma=$((soma + ${cpf:$i:1} * (11 - i)))
    done
    local digito2=$((11 - (soma % 11)))
    [[ $digito2 -ge 10 ]] && digito2=0
    
    # Verifica os dígitos
    if [[ ${cpf:9:1} -eq $digito1 && ${cpf:10:1} -eq $digito2 ]]; then
        echo -e "${VERDE}Válido${RESET} - CPF $cpf é válido"
        return 0
    else
        echo -e "${VERMELHO}Inválido${RESET} - CPF incorreto"
        return 1
    fi
}

# Função para validar data
valida_data() {
    local data=$1
    local dia mes ano
    
    # Aceita formatos DD/MM/AAAA ou DD-MM-AAAA
    if [[ "$data" =~ ^([0-9]{2})[/-]([0-9]{2})[/-]([0-9]{4})$ ]]; then
        dia=${BASH_REMATCH[1]}
        mes=${BASH_REMATCH[2]}
        ano=${BASH_REMATCH[3]}
    else
        echo -e "${VERMELHO}Inválido${RESET} - Formato de data incorreto"
        echo "Use DD/MM/AAAA ou DD-MM-AAAA"
        return 1
    fi
    
    # Verifica mês
    if [[ $mes -lt 1 || $mes -gt 12 ]]; then
        echo -e "${VERMELHO}Inválido${RESET} - Mês deve ser entre 01 e 12"
        return 1
    fi
    
    # Verifica dias por mês
    case $mes in
        01|03|05|07|08|10|12)
            dias_max=31
            ;;
        04|06|09|11)
            dias_max=30
            ;;
        02)
            # Verifica ano bissexto
            if (( ano % 400 == 0 )) || (( ano % 4 == 0 && ano % 100 != 0 )); then
                dias_max=29
            else
                dias_max=28
            fi
            ;;
    esac
    
    if [[ $dia -lt 1 || $dia -gt $dias_max ]]; then
        echo -e "${VERMELHO}Inválido${RESET} - Dia $dia inválido para o mês $mes"
        return 1
    fi
    
    # Verifica ano
    if [[ $ano -lt 1900 || $ano -gt 2026 ]]; then
        echo -e "${AMARELO}Atenção${RESET} - Ano fora do intervalo (1900-2026)"
    fi
    
    echo -e "${VERDE}Válido${RESET} - Data $dia/$mes/$ano é válida"
    return 0
}

# Função para exibir menu
exibir_menu() {
    clear
    echo "╔══════════════════════════════════════╗"
    echo "║        VALIDADOR DE DADOS            ║"
    echo "╠══════════════════════════════════════╣"
    echo "║  1 - Validar E-mail                  ║"
    echo "║  2 - Validar CPF                     ║"
    echo "║  3 - Validar Data                    ║"
    echo "║  4 - Sair                            ║"
    echo "╚══════════════════════════════════════╝"
    echo ""
}

# Loop principal
while true; do
    exibir_menu
    echo -n "Escolha uma opção (1-4): "
    read opcao
    
    case $opcao in
        1)
            clear
            echo "=== VALIDAÇÃO DE E-MAIL ==="
            echo ""
            echo -n "Digite o e-mail: "
            read email
            echo ""
            valida_email "$email"
            echo ""
            echo -n "Pressione Enter para continuar..."
            read
            ;;
        2)
            clear
            echo "=== VALIDAÇÃO DE CPF ==="
            echo ""
            echo -n "Digite o CPF (apenas números ou com . e -): "
            read cpf
            echo ""
            valida_cpf "$cpf"
            echo ""
            echo -n "Pressione Enter para continuar..."
            read
            ;;
        3)
            clear
            echo "=== VALIDAÇÃO DE DATA ==="
            echo ""
            echo -n "Digite a data (DD/MM/AAAA ou DD-MM-AAAA): "
            read data
            echo ""
            valida_data "$data"
            echo ""
            echo -n "Pressione Enter para continuar..."
            read
            ;;
        4)
            clear
            echo "========================================="
            echo "Até logo! Obrigado por usar o validador!"
            echo "========================================="
            exit 0
            ;;
        *)
            echo ""
            echo -e "${VERMELHO}Opção inválida!${RESET} Escolha 1, 2, 3 ou 4"
            sleep 2
            ;;
    esac
done
