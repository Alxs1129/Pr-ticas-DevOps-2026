#!/bin/bash
# Script: processa_log.sh
# Extrair IPs do syslog e gerar relatório

# Função para extrair IPs
extrair_ips() {
    grep -E -o '([0-9]{1,3}\.){3}[0-9]{1,3}' "$1" | sort -u
}

# Criar diretório para relatórios
mkdir -p relatorios

# Data atual
DATA=$(date +%Y%m%d_%H%M%S)
RELATORIO="relatorios/ips_$DATA.txt"

echo "=== RELATÓRIO DE IPS - $(date) ===" > "$RELATORIO"
echo "" >> "$RELATORIO"

# Verificar se o arquivo de log existe
if [ ! -f "syslog_teste.txt" ]; then
    echo "Criando arquivo de exemplo: syslog_teste.txt" >> "$RELATORIO"
    
    cat > syslog_teste.txt << 'EOF'
192.168.1.100 - - [08/Apr/2026:10:15:23] "GET /index.html"
10.0.0.1 - - [08/Apr/2026:10:16:45] "POST /login"
192.168.1.100 - - [08/Apr/2026:10:18:33] "GET /api/data"
172.16.5.2 - - [08/Apr/2026:10:20:18] "GET /dashboard"
10.0.0.1 - - [08/Apr/2026:10:21:42] "POST /upload"
192.168.1.200 - - [08/Apr/2026:10:22:56] "GET /settings"
8.8.8.8 - - [08/Apr/2026:10:23:15] "GET /dns"
192.168.1.100 - - [08/Apr/2026:10:24:33] "GET /profile"
EOF
fi

# Extrair IPs
echo "IPs encontrados no arquivo:" >> "$RELATORIO"
echo "-----------------------------" >> "$RELATORIO"
extrair_ips "syslog_teste.txt" >> "$RELATORIO"

# Adicionar estatísticas
echo "" >> "$RELATORIO"
TOTAL_IPS=$(extrair_ips "syslog_teste.txt" | wc -l)
echo "Total de IPs únicos: $TOTAL_IPS" >> "$RELATORIO"

# Mostrar o relatório na tela
echo ""
echo "========================================="
cat "$RELATORIO"
echo "========================================="
echo ""
echo "✅ Relatório salvo em: $RELATORIO"
