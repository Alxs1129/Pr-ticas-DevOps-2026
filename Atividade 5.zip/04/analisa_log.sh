#!/bin/bash
# Script: analisa_log.sh
# Função para procurar linhas com "ERROR" no syslog

# Função que analisa o log
analisa_log() {
    local LOG_FILE="/var/log/syslog"
    local DATA=$(date +%Y%m%d_%H%M%S)
    local OUTPUT_FILE="erros_${DATA}.txt"
    
    # Verificar se o arquivo de log existe
    if [ ! -f "$LOG_FILE" ]; then
        echo "ERRO: Arquivo $LOG_FILE não encontrado!"
        echo "Criando arquivo de exemplo para teste..."
        
        # Criar arquivo syslog de exemplo
        cat > syslog_exemplo.txt << 'EOF'
2026-04-15 08:30:15 INFO Servidor iniciado
2026-04-15 08:32:22 ERROR Falha na conexão com banco de dados
2026-04-15 08:35:10 WARNING Uso de CPU alto
2026-04-15 08:40:05 ERROR Timeout na requisição do usuário
2026-04-15 08:45:30 INFO Backup concluído
2026-04-15 08:50:45 ERROR Falha ao carregar módulo
2026-04-15 08:55:20 ERROR Permissão negada para acesso
2026-04-15 09:00:00 INFO Sistema estável
2026-04-15 09:05:15 ERROR Disco cheio
EOF
        LOG_FILE="syslog_exemplo.txt"
    fi
    
    # Procurar linhas com "ERROR"
    echo "=== RELATÓRIO DE ERROS - $(date) ===" > "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
    echo "Linhas encontradas com ERROR:" >> "$OUTPUT_FILE"
    echo "-----------------------------" >> "$OUTPUT_FILE"
    
    grep -i "ERROR" "$LOG_FILE" >> "$OUTPUT_FILE"
    
    # Adicionar estatísticas
    echo "" >> "$OUTPUT_FILE"
    TOTAL=$(grep -i -c "ERROR" "$LOG_FILE")
    echo "Total de erros encontrados: $TOTAL" >> "$OUTPUT_FILE"
    
    # Mostrar resultado
    echo "Relatório gerado: $OUTPUT_FILE"
    echo "Total de erros: $TOTAL"
}

# Executar a função
analisa_log
