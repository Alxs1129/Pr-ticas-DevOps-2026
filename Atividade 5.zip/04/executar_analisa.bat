@echo off
"C:\Program Files\Git\bin\bash.exe" -c "cd /c/Users/xande/Downloads/script1 && ./analisa_log.sh"

